// إعدادات المتجر: عدّل رقم واتساب إلى رقمك بصيغة دولية بدون + أو أصفار البداية.
const STORE = {
  whatsapp: "201148369371",
  currency: "ج.م",
  // الأسعار والكميات التجريبية يجب مراجعتها حسب عروض المورد والمخزون الفعلي.
};
const products = [
  {id:1,name:"منظم أدراج المطبخ",category:"drawer",desc:"ترتيب عملي للأدوات الصغيرة",price:75,tag:"اختيار عملي",image:"https://images.unsplash.com/photo-1556912172-45b7abe8b7e1?auto=format&fit=crop&w=700&q=80"},
  {id:2,name:"منظم ملاعق وأدوات",category:"drawer",desc:"كل أداة في مكانها",price:85,tag:"للمطبخ اليومي",image:"https://images.unsplash.com/photo-1556911220-bff31c812dba?auto=format&fit=crop&w=700&q=80"},
  {id:3,name:"حامل إسفنجة الحوض",category:"sink",desc:"يساعد على ترتيب مساحة الحوض",price:110,tag:"الأكثر عملية",image:"https://images.unsplash.com/photo-1600566753086-00f18fb6b3ea?auto=format&fit=crop&w=700&q=80"},
  {id:4,name:"منظم الثلاجة",category:"storage",desc:"استغلال أفضل لمساحة الثلاجة",price:150,tag:"تنظيم أسهل",image:"https://images.unsplash.com/photo-1584568694244-14fbdf83bd30?auto=format&fit=crop&w=700&q=80"},
  {id:5,name:"مشابك حفظ الأطعمة",category:"storage",desc:"حل بسيط للأكياس المفتوحة",price:55,tag:"قطعة صغيرة بفائدة",image:"https://images.unsplash.com/photo-1587049352851-8d4e89133924?auto=format&fit=crop&w=700&q=80"},
  {id:6,name:"منظم حوض متعدد الاستخدام",category:"sink",desc:"ترتيب مستلزمات التنظيف",price:180,tag:"لمسة مرتبة",image:"https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=700&q=80"}
];
let cart = JSON.parse(localStorage.getItem("rattib-cart") || "[]");
const $ = (s)=>document.querySelector(s);
const money = (n)=>`${n.toLocaleString("en-US")} ${STORE.currency}`;
function save(){localStorage.setItem("rattib-cart",JSON.stringify(cart));renderCart()}
function toast(message){const el=$("#toast");el.textContent=message;el.classList.add("show");setTimeout(()=>el.classList.remove("show"),2200)}
function renderProducts(filter="all"){
  const shown=products.filter(p=>filter==="all"||p.category===filter);
  $("#productGrid").innerHTML=shown.map(p=>`<article class="product-card">
    <div class="product-image"><img src="${p.image}" alt="${p.name}" loading="lazy"><span class="product-tag">${p.tag}</span></div>
    <div class="product-info"><h3>${p.name}</h3><p>${p.desc}</p><div class="product-buy"><span class="price">${money(p.price)}</span><button class="add-button" data-add="${p.id}">أضف للسلة +</button></div></div>
  </article>`).join("");
}
function renderCart(){
  const count=cart.reduce((s,x)=>s+x.qty,0);$("#cartCount").textContent=count;
  const items=cart.map(x=>({...products.find(p=>p.id===x.id),qty:x.qty})).filter(x=>x.id);
  $("#cartItems").innerHTML=items.length?items.map(p=>`<div class="cart-row"><div><b>${p.name}</b><small>${money(p.price)} × ${p.qty} = ${money(p.price*p.qty)}</small></div><div class="qty-controls"><button data-dec="${p.id}" aria-label="تقليل">−</button><span>${p.qty}</span><button data-inc="${p.id}" aria-label="زيادة">+</button></div></div>`).join(""):`<p class="empty-cart">لسه السلة فاضية. اختار حاجة تحب ترتب بيها مطبخك.</p>`;
  $("#cartTotal").textContent=money(items.reduce((s,p)=>s+p.price*p.qty,0));
}
function openCart(){ $("#cartDrawer").classList.add("open");$("#overlay").classList.add("show");$("#cartDrawer").setAttribute("aria-hidden","false")}
function closeCart(){ $("#cartDrawer").classList.remove("open");$("#overlay").classList.remove("show");$("#cartDrawer").setAttribute("aria-hidden","true")}
$("#productGrid").addEventListener("click",e=>{const id=Number(e.target.dataset.add);if(!id)return;const item=cart.find(x=>x.id===id);item?item.qty++:cart.push({id,qty:1});save();toast("اتضاف للسلة بنجاح")});
$("#filters").addEventListener("click",e=>{if(!e.target.matches("[data-filter]"))return;document.querySelectorAll(".filter").forEach(b=>b.classList.remove("active"));e.target.classList.add("active");renderProducts(e.target.dataset.filter)});
$("#cartItems").addEventListener("click",e=>{const inc=Number(e.target.dataset.inc),dec=Number(e.target.dataset.dec);if(inc){cart.find(x=>x.id===inc).qty++}if(dec){const item=cart.find(x=>x.id===dec);item.qty--;if(item.qty<=0)cart=cart.filter(x=>x.id!==dec)}save()});
$("#cartOpen").onclick=openCart;$("#cartClose").onclick=closeCart;$("#overlay").onclick=closeCart;
$("#checkoutButton").onclick=()=>{if(!cart.length){toast("السلة فاضية");return}closeCart();$("#checkoutDialog").showModal()};
$("#checkoutClose").onclick=()=>$("#checkoutDialog").close();
$("#checkoutForm").addEventListener("submit",e=>{
  e.preventDefault();if(!cart.length){toast("السلة فاضية");$("#checkoutDialog").close();return}
  const data=new FormData(e.target),items=cart.map(x=>{const p=products.find(p=>p.id===x.id);return `${p.name} — ${x.qty} × ${p.price} = ${p.price*x.qty} جنيه`});
  const total=cart.reduce((s,x)=>s+products.find(p=>p.id===x.id).price*x.qty,0);
  const msg=`طلب جديد من متجر رَتِّب%0A${encodeURIComponent("الاسم: "+data.get("name"))}%0A${encodeURIComponent("الموبايل: "+data.get("phone"))}%0A${encodeURIComponent("المنطقة: "+data.get("area"))}%0A${encodeURIComponent("العنوان: "+data.get("address"))}%0A${encodeURIComponent("ملاحظات: "+(data.get("notes")||"لا يوجد"))}%0A%0A${encodeURIComponent(items.join("\n"))}%0A${encodeURIComponent("إجمالي المنتجات: "+total+" جنيه")}%0A${encodeURIComponent("الشحن: يُحدد بعد التأكيد")}`;
  if(STORE.whatsapp==="201000000000"){toast("عدّل رقم واتساب المتجر في ملف app.js أولًا");return}
  window.open(`https://wa.me/${STORE.whatsapp}?text=${msg}`,"_blank","noopener");$("#checkoutDialog").close();e.target.reset();cart=[];save();
});
$("#menuToggle").onclick=()=>$(".main-nav").classList.toggle("show");
document.querySelectorAll(".main-nav a").forEach(a=>a.addEventListener("click",()=>$(".main-nav").classList.remove("show")));
$("#footerWhatsApp").href=`https://wa.me/${STORE.whatsapp}`;
$("#year").textContent=new Date().getFullYear();
renderProducts();renderCart();
